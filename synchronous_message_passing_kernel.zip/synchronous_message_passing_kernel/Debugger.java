public class Debugger{
    public static boolean isEnabled(){
        return false;
    }
    public static boolean isEnabled2(){
        return false;
    }
    public static boolean isEnabled3() {
        return false;
    }

    public static void log(Object o){
        System.out.println(o.toString());
    }
}